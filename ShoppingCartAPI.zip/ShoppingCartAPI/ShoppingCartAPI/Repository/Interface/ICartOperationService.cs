﻿using ShoppingCart.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCart.Repository.Interfaces
{
    /// <summary>
    /// ICartOperationService
    /// </summary>
    public interface ICartOperationService
    {
        List<ChartItem> GetChartItems(int cartItd);
        ChartItem AddChart(ChartItem chartItem);
        ChartItem UpdateCartItem(int cartId, ChartItem chartItem);
        ChartItem ClearCartItem(int cartId);
    }
}
