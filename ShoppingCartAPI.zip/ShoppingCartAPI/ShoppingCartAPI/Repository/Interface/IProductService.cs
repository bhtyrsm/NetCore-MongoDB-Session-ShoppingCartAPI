﻿
using ShoppingCart.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCart.Repository.Interfaces
{
    /// <summary>
    /// Product Service
    /// </summary>
    public interface IProductService
    {
        List<Product> GetProducts();
       // Product GetProduct(int id);
        Product AddProduct(Product product);
      // void DeleteProduct(int id);
       // Product UpdateProduct(Product product);
    }
}
