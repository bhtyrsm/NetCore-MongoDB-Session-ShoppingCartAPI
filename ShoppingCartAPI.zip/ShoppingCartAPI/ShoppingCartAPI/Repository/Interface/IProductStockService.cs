﻿
using ShoppingCart.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCart.Repository.Interfaces
{
    public interface IProductStockService
    {
        List<ProductStock> GetProductStocks();
        ProductStock GetProductStock(int id);
        ProductStock AddProductStock(ProductStock stock);
        void DeleteProductStock(string id);
        ProductStock UpdateProductStock(ProductStock stock);
    }
}
