﻿using Microsoft.AspNetCore.Http;
using ShoppingCart.Model;
using ShoppingCart.Repository.Interfaces;
using ShoppingCartAPI.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShoppingCart.Repository.Services
{
    public class CartOperationService : ICartOperationService
    {
        private readonly IHttpContextAccessor httpContextAccessor;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="_httpContextAccessor"></param>
        public CartOperationService(IHttpContextAccessor _httpContextAccessor)
        {
            httpContextAccessor = _httpContextAccessor;
        }

        public List<ChartItem> GetChartItems(int cartItd)
        {
            var cartList = httpContextAccessor.HttpContext.Session.GetObject<List<ChartItem>>("ShoppingCart");

            if (cartList != null)
            {
                cartList = cartList.Where(r => r.Id == cartItd.ToString()).ToList();
            }
            return cartList;
        }

        public ChartItem AddChart(ChartItem chartItem)
        {
            var cartList = httpContextAccessor.HttpContext.Session.GetObject<List<ChartItem>>("ShoppingCart");
            if (cartList == null)
            {
                cartList = new List<ChartItem>();
            }
            cartList.Add(chartItem);

            httpContextAccessor.HttpContext.Session.SetObject("ShoppingCart", cartList);
            return chartItem;
        }

        public ChartItem ClearCartItem(int cartId)
        {
            var cartList = httpContextAccessor.HttpContext.Session.GetObject<List<ChartItem>>("ShoppingCart");
            var item = new ChartItem();
            if (cartList != null)
            {
                item = cartList.Where(r => r.Id == cartId.ToString()).FirstOrDefault();
                cartList.Remove(item);
            }

            httpContextAccessor.HttpContext.Session.SetObject("ShoppingCart", cartList);
            return item;
        }


        public ChartItem UpdateCartItem(int cartId, ChartItem chartItem)
        {
            throw new NotImplementedException();
        }
    }
}
