﻿
using ShoppingCart.Model;
using ShoppingCart.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCart.Repository.Services
{
    public class ProductStockService : IProductStockService
    {
        public ProductStock AddProductStock(ProductStock stock)
        {
            throw new NotImplementedException();
        }

        public void DeleteProductStock(string id)
        {
            throw new NotImplementedException();
        }

        public ProductStock GetProductStock(int id)
        {
            throw new NotImplementedException();
        }

        public List<ProductStock> GetProductStocks()
        {
            throw new NotImplementedException();
        }

        public ProductStock UpdateProductStock(ProductStock stock)
        {
            throw new NotImplementedException();
        }
    }
}
