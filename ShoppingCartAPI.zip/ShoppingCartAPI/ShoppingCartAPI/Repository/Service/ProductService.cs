﻿using MongoDB.Driver;
using ShoppingCart.Model;
using ShoppingCart.Repository.Interfaces;
using ShoppingChart.DB;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCart.Repository.Services
{
    public class ProductService : IProductService
    {
        private readonly IMongoCollection<Product> productCollection;

        public ProductService(IDBClient dbClient)
        {
            productCollection = dbClient.GetProductCollection();
        }
        public Product AddProduct(Product product)
        {
            productCollection.InsertOne(product);
            return product;
        }

        //public void DeleteProduct(int id)
        //{
        //    throw new NotImplementedException();
        //}

        //public Product GetProduct(int id)
        //{
        //    throw new NotImplementedException();
        //}

        public List<Product> GetProducts()
        { 
            return productCollection.Find(product=>true).ToList();
        }

        //public Product UpdateProduct(Product product)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
