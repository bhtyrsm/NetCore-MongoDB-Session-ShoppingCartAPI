﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Model;
using ShoppingCart.Repository.Interfaces;

namespace ShoppingChartAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProductService productService;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="_productService"></param>
        public ProductController(IProductService _productService)
        {
            productService = _productService;
        }


        /// <summary>
        /// GetProducts
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetProducts()
        {
            return Ok(productService.GetProducts());
        }

        ///// <summary>
        ///// GetProduct
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //[HttpGet("{id}", Name = "GetProduct")]
        //public IActionResult GetProduct(int id)
        //{
        //    return Ok(productService.GetProduct(id));
        //}

        /// <summary>
        /// AddProduct
        /// </summary>
        /// <param name="book"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult AddProduct(Product product)
        {
            productService.AddProduct(product);
            return CreatedAtRoute("GetProduct", new { id = product.Id }, product);
        }

        ///// <summary>
        ///// DeleteProduct
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //[HttpDelete("{id}")]
        //public IActionResult DeleteProduct(int id)
        //{
        //    productService.DeleteProduct(id);
        //    return NoContent();
        //}

        ///// <summary>
        ///// UpdateProduct
        ///// </summary>
        ///// <param name="book"></param>
        ///// <returns></returns>
        //[HttpPut]
        //public IActionResult UpdateProduct(Product product)
        //{
        //    return Ok(productService.UpdateProduct(product));
        //}
    }
}