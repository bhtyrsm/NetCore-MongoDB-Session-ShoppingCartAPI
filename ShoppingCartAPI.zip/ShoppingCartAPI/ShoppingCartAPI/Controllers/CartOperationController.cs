﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Model;
using ShoppingCart.Repository.Interfaces;

namespace ShoppingChartAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CartOperationController : Controller
    {
        private readonly ICartOperationService cartOperationService;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="_cartOperationService"></param>
        public CartOperationController(ICartOperationService _cartOperationService)
        {
            cartOperationService = _cartOperationService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="chartId"></param>
        /// <returns></returns>
        [HttpGet("GetCartItems/{chartId}")]
        public IActionResult GetCartItems(int chartId)
        {
            return Ok(cartOperationService.GetChartItems(chartId));
        }


        /// <summary>
        /// Add CartItem
        /// </summary>
        /// <param name="cartItem"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult  Post([FromBody] ChartItem cartItem)
        {
            return Ok(cartOperationService.AddChart(cartItem));
        }



        [HttpPut]
        public IActionResult PutChartItem(int id, ChartItem product)
        {
            //NOT IMPLEMENT
            return NotFound("THİS METHOD İS NOT IMPLEMENTED" );
        }


        [HttpDelete("ClearCart/{cartId}")]
        public IActionResult ClearCart(int cartId)
        {
            
            //NOT IMPLEMENT
            return NotFound("THİS METHOD İS NOT IMPLEMENTED");
        }


    }
}