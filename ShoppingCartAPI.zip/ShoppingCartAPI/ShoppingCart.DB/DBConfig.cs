﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingChart.DB
{
    public class DBConfig
    {
        public string DATABASE_NAME { get; set; }
        public string CART_COLLECTION_NAME { get; set; }
        public string PRODUCT_COLLECTION_NAME { get; set; }
        public string PRODUCT_STOCK_COLLECTION_NAME { get; set; }     
        public string CONNECTION_STRING { get; set; }
    }
}
