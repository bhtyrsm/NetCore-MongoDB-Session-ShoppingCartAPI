﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using ShoppingCart.Model;

namespace ShoppingChart.DB
{
    public class DBClient : IDBClient
    {
        private readonly IMongoCollection<Product> product;
        private readonly IMongoCollection<ChartItem> chartItem;
        private readonly IMongoCollection<ProductStock> productStock;

        public DBClient(IOptions<DBConfig> dbConfig)
        {
            //var client = new MongoClient(dbConfig.Value.CONNECTION_STRING);
            var settings = MongoClientSettings.FromConnectionString("mongodb+srv://bahtiyardeneme:pas12345@cluster0.wobfu.mongodb.net/ShoppingCartDB?retryWrites=true&w=majority");
            var client = new MongoClient(settings);
            var database = client.GetDatabase(dbConfig.Value.DATABASE_NAME);
            product = database.GetCollection<Product>(dbConfig.Value.PRODUCT_COLLECTION_NAME);
            productStock = database.GetCollection<ProductStock>(dbConfig.Value.PRODUCT_STOCK_COLLECTION_NAME);
            chartItem = database.GetCollection<ChartItem>(dbConfig.Value.CART_COLLECTION_NAME);
        }

       public IMongoCollection<Product> GetProductCollection() => product;
       public IMongoCollection<ProductStock> GetProductStockCollection() => productStock;
       public IMongoCollection<ChartItem> GetCartItemCollection() => chartItem;
    }
}
