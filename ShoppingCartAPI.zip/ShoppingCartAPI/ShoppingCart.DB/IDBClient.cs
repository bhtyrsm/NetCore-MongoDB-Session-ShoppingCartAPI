﻿using MongoDB.Driver;
using ShoppingCart.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingChart.DB
{
    public interface IDBClient
    {
        IMongoCollection<Product> GetProductCollection();
        IMongoCollection<ProductStock> GetProductStockCollection();
        IMongoCollection<ChartItem> GetCartItemCollection();
    }
}
